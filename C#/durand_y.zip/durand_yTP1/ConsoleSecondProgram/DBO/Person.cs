﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleSecondProgram.DBO
{
    public class Person
    {
        public String Adress { get; set; }
        public String FirstName { get; set; }
        public String Name { get; set; }
    }
}
