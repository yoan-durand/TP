package com.mti.sample;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        HelloWorld h = new HelloWorld();
        
        System.out.println(h.helloWorld("yoan"));
    }
}
