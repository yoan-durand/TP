/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mti.sample;

/**
 *
 * @author durand_y
 */
public class HelloWorld 
{
    public String helloWorld(String name)
    {
        String str = "Hello ";
        if (name == null)
            str += "World !";
        else
        {
            str += name;
            str += " !";
        }
        return (str);
    }
}
