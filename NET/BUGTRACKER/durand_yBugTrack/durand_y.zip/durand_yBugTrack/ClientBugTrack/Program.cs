﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ClientBugTrack
{
    class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
